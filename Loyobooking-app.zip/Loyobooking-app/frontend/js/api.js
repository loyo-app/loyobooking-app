// Small fetch wrapper + auth-state helpers shared by every page.

function getToken() {
  return localStorage.getItem('lb_token');
}
function getUser() {
  const raw = localStorage.getItem('lb_user');
  return raw ? JSON.parse(raw) : null;
}
function setSession(token, user) {
  localStorage.setItem('lb_token', token);
  localStorage.setItem('lb_user', JSON.stringify(user));
}
function clearSession() {
  localStorage.removeItem('lb_token');
  localStorage.removeItem('lb_user');
}
function logout() {
  clearSession();
  window.location.href = 'index.html';
}

// Redirects to the correct dashboard for a role, or to login if none given.
function goToDashboard(role) {
  if (role === 'owner') window.location.href = 'owner.html';
  else if (role === 'barber') window.location.href = 'barber.html';
  else if (role === 'customer') window.location.href = 'customer.html';
  else window.location.href = 'index.html';
}

// Guards a dashboard page: bounces back to login if not authenticated
// as the expected role.
function requireRole(role) {
  const user = getUser();
  const token = getToken();
  if (!token || !user || user.role !== role) {
    window.location.href = 'index.html';
    return null;
  }
  return user;
}

async function api(path, { method = 'GET', body, auth = true } = {}) {
  const headers = { 'Content-Type': 'application/json' };
  if (auth) {
    const token = getToken();
    if (token) headers['Authorization'] = `Bearer ${token}`;
  }
  const res = await fetch(`${API_BASE_URL}${path}`, {
    method,
    headers,
    body: body ? JSON.stringify(body) : undefined
  });
  let data = null;
  try {
    data = await res.json();
  } catch (e) {
    // no body
  }
  if (!res.ok) {
    const message = (data && data.error) || `Request failed (${res.status})`;
    throw new Error(message);
  }
  return data;
}

function showMessage(el, text, isError = true) {
  el.textContent = text;
  el.className = isError ? 'msg msg-error' : 'msg msg-success';
  el.style.display = text ? 'block' : 'none';
}
