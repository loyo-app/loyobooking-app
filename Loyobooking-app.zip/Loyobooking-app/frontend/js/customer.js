const user = requireRole('customer');

const barberSelect = document.getElementById('barber-select');
const serviceSelect = document.getElementById('service-select');
const bookingForm = document.getElementById('booking-form');
const bookingMsg = document.getElementById('booking-msg');
const bookingsContainer = document.getElementById('bookings-container');

// Prevent picking a date in the past.
document.getElementById('date-input').min = new Date().toISOString().split('T')[0];

async function loadFormOptions() {
  try {
    const [barbers, services] = await Promise.all([
      api('/api/staff', { auth: false }),
      api('/api/bookings/services', { auth: false })
    ]);
    barberSelect.innerHTML = barbers.length
      ? barbers.map(b => `<option value="${b.id}">${b.full_name || b.username}</option>`).join('')
      : '<option value="">No barbers available yet</option>';
    serviceSelect.innerHTML = services.map(s => `<option value="${s}">${s}</option>`).join('');
  } catch (err) {
    showMessage(bookingMsg, err.message);
  }
}

function statusBadge(status) {
  return `<span class="status-badge status-${status}">${status}</span>`;
}

async function loadBookings() {
  try {
    const bookings = await api('/api/bookings/mine');
    if (bookings.length === 0) {
      bookingsContainer.innerHTML = '<p class="empty-state">No bookings yet — book your first appointment above.</p>';
      return;
    }
    const rows = bookings.map(b => `
      <tr>
        <td>${b.booking_date}</td>
        <td>${b.booking_time.slice(0, 5)}</td>
        <td>${b.barber_name || b.barber_username}</td>
        <td>${b.service}</td>
        <td>${statusBadge(b.status)}</td>
        <td>${b.status === 'confirmed' ? `<button class="btn-small btn-danger" data-id="${b.id}">Cancel</button>` : ''}</td>
      </tr>
    `).join('');
    bookingsContainer.innerHTML = `
      <table>
        <thead><tr><th>Date</th><th>Time</th><th>Barber</th><th>Service</th><th>Status</th><th></th></tr></thead>
        <tbody>${rows}</tbody>
      </table>
    `;
    bookingsContainer.querySelectorAll('button[data-id]').forEach(btn => {
      btn.addEventListener('click', () => cancelBooking(btn.dataset.id));
    });
  } catch (err) {
    bookingsContainer.innerHTML = `<p class="empty-state">Could not load bookings: ${err.message}</p>`;
  }
}

async function cancelBooking(id) {
  if (!confirm('Cancel this booking?')) return;
  try {
    await api(`/api/bookings/${id}/cancel`, { method: 'PATCH' });
    loadBookings();
  } catch (err) {
    alert(err.message);
  }
}

bookingForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  showMessage(bookingMsg, '');
  const barber_id = barberSelect.value;
  const service = serviceSelect.value;
  const booking_date = document.getElementById('date-input').value;
  const booking_time = document.getElementById('time-input').value;
  if (!barber_id) {
    showMessage(bookingMsg, 'No barber selected.');
    return;
  }
  try {
    await api('/api/bookings', { method: 'POST', body: { barber_id, service, booking_date, booking_time } });
    showMessage(bookingMsg, 'Booking confirmed!', false);
    bookingForm.reset();
    loadBookings();
  } catch (err) {
    showMessage(bookingMsg, err.message);
  }
});

loadFormOptions();
loadBookings();
