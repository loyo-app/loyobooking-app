// After you deploy the backend to Railway, paste its public URL below.
// Example: "https://loyobooking-backend-production.up.railway.app"
const API_BASE_URL = "https://YOUR-RAILWAY-APP.up.railway.app";
