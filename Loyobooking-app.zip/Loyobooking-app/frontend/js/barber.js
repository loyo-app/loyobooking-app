const user = requireRole('barber');

const bookingsContainer = document.getElementById('bookings-container');

function statusBadge(status) {
  return `<span class="status-badge status-${status}">${status}</span>`;
}

async function loadBookings() {
  try {
    const bookings = await api('/api/bookings/barber');
    if (bookings.length === 0) {
      bookingsContainer.innerHTML = '<p class="empty-state">No appointments booked with you yet.</p>';
      return;
    }
    const rows = bookings.map(b => `
      <tr>
        <td>${b.booking_date}</td>
        <td>${b.booking_time.slice(0, 5)}</td>
        <td>${b.customer_name || b.customer_username}</td>
        <td>${b.customer_phone || '—'}</td>
        <td>${b.service}</td>
        <td>${statusBadge(b.status)}</td>
        <td>${b.status === 'confirmed' ? `<button class="btn-small btn-danger" data-id="${b.id}">Cancel</button>` : ''}</td>
      </tr>
    `).join('');
    bookingsContainer.innerHTML = `
      <table>
        <thead><tr><th>Date</th><th>Time</th><th>Customer</th><th>Phone</th><th>Service</th><th>Status</th><th></th></tr></thead>
        <tbody>${rows}</tbody>
      </table>
    `;
    bookingsContainer.querySelectorAll('button[data-id]').forEach(btn => {
      btn.addEventListener('click', () => cancelBooking(btn.dataset.id));
    });
  } catch (err) {
    bookingsContainer.innerHTML = `<p class="empty-state">Could not load appointments: ${err.message}</p>`;
  }
}

async function cancelBooking(id) {
  if (!confirm('Cancel this appointment?')) return;
  try {
    await api(`/api/bookings/${id}/cancel`, { method: 'PATCH' });
    loadBookings();
  } catch (err) {
    alert(err.message);
  }
}

loadBookings();
