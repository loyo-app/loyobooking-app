// If already logged in, skip straight to the right dashboard.
(function () {
  const user = getUser();
  if (user && getToken()) goToDashboard(user.role);
})();

const tabLogin = document.getElementById('tab-login');
const tabRegister = document.getElementById('tab-register');
const loginForm = document.getElementById('login-form');
const registerForm = document.getElementById('register-form');
const msgEl = document.getElementById('msg');

tabLogin.addEventListener('click', () => {
  tabLogin.classList.add('active');
  tabRegister.classList.remove('active');
  loginForm.style.display = 'block';
  registerForm.style.display = 'none';
  showMessage(msgEl, '');
});

tabRegister.addEventListener('click', () => {
  tabRegister.classList.add('active');
  tabLogin.classList.remove('active');
  registerForm.style.display = 'block';
  loginForm.style.display = 'none';
  showMessage(msgEl, '');
});

loginForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  showMessage(msgEl, '');
  const username = document.getElementById('login-username').value.trim();
  const password = document.getElementById('login-password').value;
  try {
    const data = await api('/api/auth/login', { method: 'POST', body: { username, password }, auth: false });
    setSession(data.token, data.user);
    goToDashboard(data.user.role);
  } catch (err) {
    showMessage(msgEl, err.message);
  }
});

registerForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  showMessage(msgEl, '');
  const full_name = document.getElementById('reg-name').value.trim();
  const phone = document.getElementById('reg-phone').value.trim();
  const username = document.getElementById('reg-username').value.trim();
  const password = document.getElementById('reg-password').value;
  try {
    const data = await api('/api/auth/register', { method: 'POST', body: { username, password, full_name, phone }, auth: false });
    setSession(data.token, data.user);
    goToDashboard(data.user.role);
  } catch (err) {
    showMessage(msgEl, err.message);
  }
});
