// Run once (locally or via `railway run node migrate.js`) to create tables
// and seed the initial owner account from environment variables.
require('dotenv').config();
const fs = require('fs');
const path = require('path');
const bcrypt = require('bcryptjs');
const pool = require('./db');

async function migrate() {
  const schema = fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf8');
  await pool.query(schema);
  console.log('Schema created.');

  const ownerUsername = process.env.OWNER_USERNAME || 'owner';
  const ownerPassword = process.env.OWNER_PASSWORD || 'changeme123';

  const existing = await pool.query('SELECT id FROM users WHERE username = $1', [ownerUsername]);
  if (existing.rows.length === 0) {
    const hash = await bcrypt.hash(ownerPassword, 10);
    await pool.query(
      'INSERT INTO users (username, password_hash, role, full_name) VALUES ($1, $2, $3, $4)',
      [ownerUsername, hash, 'owner', 'Shop Owner']
    );
    console.log(`Owner account created: username="${ownerUsername}" password="${ownerPassword}"`);
    console.log('IMPORTANT: log in and note this down, then set OWNER_USERNAME/OWNER_PASSWORD env vars to something private.');
  } else {
    console.log('Owner account already exists, skipping seed.');
  }

  await pool.end();
}

migrate().catch(err => {
  console.error('Migration failed:', err);
  process.exit(1);
});
