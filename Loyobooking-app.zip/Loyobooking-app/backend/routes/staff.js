const express = require('express');
const bcrypt = require('bcryptjs');
const pool = require('../db');
const { requireAuth, requireRole } = require('../middleware/auth');

const router = express.Router();

// List all barbers — public-ish, so customers can pick one when booking.
router.get('/', async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT id, username, full_name FROM users WHERE role = 'barber' ORDER BY full_name NULLS LAST, username`
    );
    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error fetching staff' });
  }
});

// Owner creates a new barber account.
router.post('/', requireAuth, requireRole('owner'), async (req, res) => {
  try {
    const { username, password, full_name, phone } = req.body;
    if (!username || !password) {
      return res.status(400).json({ error: 'Username and password are required' });
    }
    if (password.length < 6) {
      return res.status(400).json({ error: 'Password must be at least 6 characters' });
    }
    const existing = await pool.query('SELECT id FROM users WHERE username = $1', [username]);
    if (existing.rows.length > 0) {
      return res.status(409).json({ error: 'Username already taken' });
    }
    const hash = await bcrypt.hash(password, 10);
    const result = await pool.query(
      `INSERT INTO users (username, password_hash, role, full_name, phone)
       VALUES ($1, $2, 'barber', $3, $4)
       RETURNING id, username, role, full_name, phone`,
      [username, hash, full_name || null, phone || null]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error creating staff account' });
  }
});

// Owner removes a barber account.
router.delete('/:id', requireAuth, requireRole('owner'), async (req, res) => {
  try {
    const { id } = req.params;
    const result = await pool.query(
      `DELETE FROM users WHERE id = $1 AND role = 'barber' RETURNING id`,
      [id]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Barber not found' });
    }
    res.json({ success: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error removing staff account' });
  }
});

module.exports = router;
