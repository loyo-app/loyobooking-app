const express = require('express');
const pool = require('../db');
const { requireAuth, requireRole } = require('../middleware/auth');

const router = express.Router();

const SERVICES = [
  'Adult Haircut',
  'Kids Haircut',
  'Shave',
  'Brazilian Keratin',
  'Korean Perm',
  'Loose Perm'
];

router.get('/services', (req, res) => {
  res.json(SERVICES);
});

// Customer creates a booking.
router.post('/', requireAuth, requireRole('customer'), async (req, res) => {
  try {
    const { barber_id, service, booking_date, booking_time } = req.body;
    if (!barber_id || !service || !booking_date || !booking_time) {
      return res.status(400).json({ error: 'barber_id, service, booking_date, and booking_time are all required' });
    }
    if (!SERVICES.includes(service)) {
      return res.status(400).json({ error: 'Invalid service' });
    }
    const barberCheck = await pool.query(`SELECT id FROM users WHERE id = $1 AND role = 'barber'`, [barber_id]);
    if (barberCheck.rows.length === 0) {
      return res.status(400).json({ error: 'Selected barber does not exist' });
    }
    // Prevent double-booking the same barber at the same date/time.
    const clash = await pool.query(
      `SELECT id FROM bookings WHERE barber_id = $1 AND booking_date = $2 AND booking_time = $3 AND status = 'confirmed'`,
      [barber_id, booking_date, booking_time]
    );
    if (clash.rows.length > 0) {
      return res.status(409).json({ error: 'That barber already has a booking at this date/time' });
    }
    const result = await pool.query(
      `INSERT INTO bookings (customer_id, barber_id, service, booking_date, booking_time)
       VALUES ($1, $2, $3, $4, $5) RETURNING *`,
      [req.user.id, barber_id, service, booking_date, booking_time]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error creating booking' });
  }
});

// Customer views their own bookings.
router.get('/mine', requireAuth, requireRole('customer'), async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT b.*, u.full_name AS barber_name, u.username AS barber_username
       FROM bookings b JOIN users u ON u.id = b.barber_id
       WHERE b.customer_id = $1
       ORDER BY b.booking_date, b.booking_time`,
      [req.user.id]
    );
    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error fetching bookings' });
  }
});

// Barber views bookings assigned to them.
router.get('/barber', requireAuth, requireRole('barber'), async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT b.*, u.full_name AS customer_name, u.username AS customer_username, u.phone AS customer_phone
       FROM bookings b JOIN users u ON u.id = b.customer_id
       WHERE b.barber_id = $1
       ORDER BY b.booking_date, b.booking_time`,
      [req.user.id]
    );
    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error fetching bookings' });
  }
});

// Owner views all bookings across the shop.
router.get('/all', requireAuth, requireRole('owner'), async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT b.*,
              cu.full_name AS customer_name, cu.username AS customer_username,
              ba.full_name AS barber_name, ba.username AS barber_username
       FROM bookings b
       JOIN users cu ON cu.id = b.customer_id
       JOIN users ba ON ba.id = b.barber_id
       ORDER BY b.booking_date, b.booking_time`
    );
    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error fetching bookings' });
  }
});

// Cancel a booking — the owner, the assigned barber, or the customer who made it.
router.patch('/:id/cancel', requireAuth, async (req, res) => {
  try {
    const { id } = req.params;
    const bookingResult = await pool.query('SELECT * FROM bookings WHERE id = $1', [id]);
    if (bookingResult.rows.length === 0) {
      return res.status(404).json({ error: 'Booking not found' });
    }
    const booking = bookingResult.rows[0];
    const allowed =
      req.user.role === 'owner' ||
      (req.user.role === 'barber' && req.user.id === booking.barber_id) ||
      (req.user.role === 'customer' && req.user.id === booking.customer_id);
    if (!allowed) {
      return res.status(403).json({ error: 'Not authorized to cancel this booking' });
    }
    const result = await pool.query(
      `UPDATE bookings SET status = 'cancelled' WHERE id = $1 RETURNING *`,
      [id]
    );
    res.json(result.rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error cancelling booking' });
  }
});

module.exports = router;
