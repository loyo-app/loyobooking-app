require('dotenv').config();
const express = require('express');
const cors = require('cors');

const authRoutes = require('./routes/auth');
const staffRoutes = require('./routes/staff');
const bookingRoutes = require('./routes/bookings');

const app = express();

// Allow requests from your GitHub Pages site. Set FRONTEND_ORIGIN in Railway's
// env vars to something like: https://yourusername.github.io
const allowedOrigin = process.env.FRONTEND_ORIGIN || '*';
app.use(cors({ origin: allowedOrigin }));
app.use(express.json());

app.get('/', (req, res) => res.json({ status: 'Loyobooking-app API is running' }));
app.get('/api/health', (req, res) => res.json({ ok: true }));

app.use('/api/auth', authRoutes);
app.use('/api/staff', staffRoutes);
app.use('/api/bookings', bookingRoutes);

app.use((req, res) => res.status(404).json({ error: 'Not found' }));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Loyobooking-app API listening on port ${PORT}`));
